import React from 'react';
import { View, Text } from 'react-native';

export default function User() {
    return (
        <View>
            <Text>User</Text>
        </View>
    )
}